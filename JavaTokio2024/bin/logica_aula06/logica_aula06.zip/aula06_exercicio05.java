package logica_aula06;

import java.util.Scanner;

public class aula06_exercicio05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um numero: ");
		float num1 = sc.nextFloat();
		
		System.out.println("Digite um numero 2:");
		float num2 = sc.nextFloat();
		
		System.out.println("Digite uns dos caracteres \n +  -  *  /");
		char operacao = 
	}

}
